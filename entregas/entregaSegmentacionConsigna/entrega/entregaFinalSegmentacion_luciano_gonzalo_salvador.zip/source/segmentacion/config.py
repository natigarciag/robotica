# Autores:
# Luciano Garcia Giordano - 150245
# Gonzalo Florez Arias - 150048
# Salvador Gonzalez Gerpe - 150044

numberOfImages = 5

imageShape = {
    'width': 320,
    'height': 240
}

datasetName = 'Entrega'